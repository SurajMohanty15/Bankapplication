package com.fis.bankapplication.service;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.bankapplication.dao.CustomerDao;
import com.fis.bankapplication.exceptions.CustomerNotFound;
import com.fis.bankapplication.model.Customer;
import com.fis.bankapplication.service.CustomerService;

@Service
@Transactional
public class CustomerServiceImpl implements CustomerService{
	
	@Autowired
	private CustomerDao customerDAO;
	
	@Override
	public String addUser(Customer customer) {
		return customerDAO.addUser(customer);
	}

	@Override
	public String updateUser(int customerId,String name,String address) throws CustomerNotFound {
		return customerDAO.updateUser(customerId, address, address);
	}

	@Override
	public String deleteUser(int customerId) {
		return customerDAO.deleteUser(customerId);
	}

	@Override
	public Customer getUser(int customerId) throws CustomerNotFound {
		return customerDAO.getUser(customerId);}

	@Override
	public List<Customer> getAllCustomer() {
		return customerDAO.getAllCustomer();
	}
}
