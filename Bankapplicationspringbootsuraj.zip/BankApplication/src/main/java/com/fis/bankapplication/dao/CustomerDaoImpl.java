package com.fis.bankapplication.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.fis.bankapplication.dao.CustomerDao;
import com.fis.bankapplication.exceptions.CustomerNotFound;
import com.fis.bankapplication.model.Customer;

@Repository
@Transactional
public class CustomerDaoImpl implements CustomerDao {
	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public String addUser(Customer customer) {
		entityManager.persist(customer);
		return "Customer added to the database.";
	}

	@Override
	public String updateUser(int customerId,String name,String address) throws CustomerNotFound{
		Customer existingCustomer = entityManager.find(Customer.class, customerId);
		if(existingCustomer!=null) {
			existingCustomer.setName(name);
		existingCustomer.setAddress(address);
		entityManager.merge(existingCustomer);
		return "Customer Updated Successfully";
		}
		else
		{
			throw new CustomerNotFound("Customer not found wiht id:" + customerId);
		}
		
	}

	@Override
	public String deleteUser(int customerId) {
		Customer customer = entityManager.find(Customer.class, customerId);
		if(customer != null) {
			entityManager.remove(customer);
			return "Customer deleted.";
		}
		else{
			return "Customer not found in database.";
		}
	}

	@Override
	public Customer getUser(int customerId) throws CustomerNotFound {
		Customer existingCustomer = entityManager.find(Customer.class, customerId);
		if(existingCustomer != null) {
		return entityManager.find(Customer.class, customerId);
	} else {
		throw new CustomerNotFound("Customer not found");
	}
	}

	@Override
	public List<Customer> getAllCustomer() {
		return entityManager.createQuery("Select c from Customer c",Customer.class).getResultList();
	}

}
