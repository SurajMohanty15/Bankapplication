package com.fis.bankapplication.service;

import java.util.List;

import com.fis.bankapplication.exceptions.CustomerNotFound;
import com.fis.bankapplication.model.Customer;

public interface CustomerService {
	public abstract String addUser(Customer customer);
	public abstract String updateUser(int customerId,String name,String address) throws CustomerNotFound;
	public abstract String deleteUser(int customerId);
	public abstract Customer getUser(int customerId) throws CustomerNotFound;
	public abstract List<Customer> getAllCustomer();
}
