package com.fis.bankapplication.dao;

import java.util.List;

import com.fis.bankapplication.exceptions.AccountNotFound;
import com.fis.bankapplication.model.Account;

public interface AccountDao {
	
	public abstract String addAccount(Account account);
	public abstract Account getAccountByAccountId(int accountId) throws AccountNotFound;
	public abstract String updateAccount(int accountId,double amount);
	public abstract void deleteAccount(int accountId);
	public abstract List<Account> getAllAccountsByBalanceRange (double minBal,double maxBal);
	public abstract List<Account> getAllAccounts();
}
